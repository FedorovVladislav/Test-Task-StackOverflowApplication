//
//  Items.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on January 28, 2022
//
import Foundation

struct Items: Codable {

	let tags: [String]
	let owner: Owner
	let isAnswered: Bool
	let viewCount: Int
	let answerCount: Int
	let score: Int
	let lastActivityDate: Int
	let creationDate: Int
	let questionId: Int
	let contentLicense: String
	let link: String
	let title: String

}