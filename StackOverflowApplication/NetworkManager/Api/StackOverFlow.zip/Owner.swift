//
//  Owner.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on January 28, 2022
//
import Foundation

struct Owner: Codable {

	let accountId: Int
	let reputation: Int
	let userId: Int
	let userType: String
	let acceptRate: Int
	let profileImage: String
	let displayName: String
	let link: String

}