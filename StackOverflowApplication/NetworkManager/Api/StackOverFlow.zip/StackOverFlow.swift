//
//  StackOverFlow.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on January 28, 2022
//
import Foundation

struct StackOverFlow: Codable {

	let items: [Items]
	let hasMore: Bool
	let quotaMax: Int
	let quotaRemaining: Int

}